### JobPrepRelease

The JobPrepRelease sample project backs the code snippets found in [Run job preparation and completion tasks on Azure Batch compute nodes](http://azure.microsoft.com/documentation/articles/batch-job-prep-release/). The application demonstrates the creation of a CloudJob configured with job preparation and release tasks, then prints information to the console detailing the execution of these and the other CloudTasks.
